package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.pojo.ShowDetails;

public interface ShowDaoIf extends JpaRepository<ShowDetails, Long> {

	//error
	@Query(value = "select sd.id, end_time, start_time,  movie_id, sd.cinemahall_id, show_status from show_details sd ,movie m where sd.movie_id=m.id and(show_status='FEATURING' or show_status='UPCOMING')",nativeQuery = true)
	List<ShowDetails> findByMovieSelected(Long movieId);
}
