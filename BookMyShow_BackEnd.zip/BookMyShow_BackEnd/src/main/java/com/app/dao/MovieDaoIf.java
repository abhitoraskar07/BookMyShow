package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.app.dto.MovieDTO;
import com.app.pojo.Movie;
import com.app.pojo.MovieStatus;


public interface MovieDaoIf extends JpaRepository<Movie, Long>{
   	
	
	//-----------------Query retrieving current movies----------------------------------------//
    @Query("select m from Movie m where m.movieStatus='CURRENT'")
	List<Movie> findByMovieStatusCURRENT();
	
    //---------------Query retriving list of current streaming movies in the provided city--------------------//
    @Query("SELECT m FROM Movie m JOIN m.cinemaHall ch WHERE ch.city = :city AND m.movieStatus = 'CURRENT'")
	List<Movie> findByCityandMovieStatusCURRENT(String city);
    
    //--------------for admin-------------///
    //-------Query retrieving list of movies according to movie status-------------------//
    @Query("SELECT m FROM Movie m ORDER BY m.movieStatus ASC")
    List<Movie> findAllByOrderByMovieStatusAsc();
}
 