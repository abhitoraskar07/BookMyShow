package com.app.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.app.custom_exception.CustomException;
import com.app.dao.UserDaoIf;
import com.app.dto.AuthenticateResponse;
import com.app.dto.SignInRequest;
import com.app.dto.SignUpRequest;
import com.app.dto.UserProfileDTO;
import com.app.pojo.User;

@Service
@Transactional
public class UserService implements UserServiceIf, UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		return userEntityDao.findByEmail(username).get();
	}
	
	@Autowired
	private TokenService tokenService;
	
	@Autowired
	private AuthenticationManager authenticationManger;
	
	@Autowired
	private UserDaoIf userEntityDao;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private PasswordEncoder encoder;

	public AuthenticateResponse registerUser(SignUpRequest signUpUser) {
		// map dto --> entity
	 String pass = encoder.encode(signUpUser.getPassword());
	 signUpUser.setPassword(pass);
				User user = mapper.map(signUpUser, User.class);
				// invoke dao's method for saving emp dtls in DB
				User user2= userEntityDao.save(user);
				// map entity --> dto
				return mapper.map(user2, AuthenticateResponse.class);
	}

	
	public String signInUser(SignInRequest signInUser) {		
//		User user = userEntityDao.findByEmailAndPassword(signInUser.getEmail(),signInUser.getPassword()).orElseThrow(()->new CustomException("Wrong credentials...!!"));
//		System.out.println(user);
//		//for mapping user we need to use get() at type of user is Optional
//		return mapper.map(user ,  AuthenticateResponse.class );
	   try{
            Authentication auth = authenticationManger.authenticate(
                    new UsernamePasswordAuthenticationToken(signInUser.getEmail(), signInUser.getPassword())
                );

                String token = tokenService.generateJwt(auth);

                return token;

            } catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				 return "failed";
			}
	   
        }
		
	

	
	public UserProfileDTO updateUserDetails(Long userId, UserProfileDTO userDto) {
		User user= userEntityDao.findById(userId).orElseThrow(()->new CustomException("UserId not valid....!"));
		mapper.map(userDto, user);
		user.setId(userId);
		return mapper.map(user, UserProfileDTO.class);
	}


	

}
