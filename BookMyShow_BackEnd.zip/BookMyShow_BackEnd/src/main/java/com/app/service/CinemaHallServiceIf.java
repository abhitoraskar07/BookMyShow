package com.app.service;

import java.util.List;

import com.app.dto.CinemaHallDTO;


public interface CinemaHallServiceIf {
   List <CinemaHallDTO> showCityHalls(String city);
}
