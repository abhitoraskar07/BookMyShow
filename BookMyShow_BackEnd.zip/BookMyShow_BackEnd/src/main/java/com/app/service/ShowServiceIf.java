package com.app.service;

import java.time.LocalDateTime;
import java.util.List;

import com.app.dto.ShowDTO;
import com.app.pojo.ShowDetails;

public interface ShowServiceIf {
	
	void addShowDetailsOfExistingMovie(Long movieId,ShowDTO sh_dtls);
    void removeShowDetails(Long Id);
    List<ShowDTO> displayMovieShows(Long Id);
}
