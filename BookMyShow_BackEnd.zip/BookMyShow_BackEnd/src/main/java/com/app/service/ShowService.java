package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exception.CustomException;
import com.app.dao.MovieDaoIf;
import com.app.dao.ShowDaoIf;
import com.app.dto.ShowDTO;
import com.app.pojo.Movie;
import com.app.pojo.ShowDetails;

@Service
@Transactional
public class ShowService implements ShowServiceIf {

	@Autowired
	private ShowDaoIf showDao;
	
	@Autowired
	private MovieDaoIf movieDao;
	
	@Autowired
	private ModelMapper mapper;
	
	//--------------------- Adding Show details of an existing movie ----------------------------//
	@Override
	public void addShowDetailsOfExistingMovie(Long movieId,ShowDTO sh_dtls_dto) {
	  Movie movie = movieDao.findById(movieId).orElseThrow(()->new CustomException("movieId not valid...!!"));
	  ShowDetails sh_dtls= mapper.map(sh_dtls_dto, ShowDetails.class);
	  movie.addShowDetails(sh_dtls);
	  showDao.save(sh_dtls);	 
	}
	
	public void removeShowDetails(Long Id) {
		  ShowDetails sh_dtls=showDao.findById(Id).orElseThrow(()->new CustomException("showId not valid...!"));
		  showDao.delete(sh_dtls);
		  //find by id, showdetails flag, svae
		}

	@Override
	public List<ShowDTO> displayMovieShows(Long Id) {
	    List<ShowDetails> showList=showDao.findByMovieSelected(Id);
		return showList.stream()
				.map(show->mapper.map(showList, ShowDTO.class))
				.collect(Collectors.toList());
	}

}
