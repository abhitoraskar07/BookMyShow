package com.app.service;

import java.util.List;

import com.app.dto.MovieDTO;
import com.app.pojo.Movie;

public interface MovieServiceIf {
   MovieDTO addNewMovie(MovieDTO movie);
   List<Movie> getAllMovies();
   List<MovieDTO> getCityCurrentMovies(String city);
   List<MovieDTO> getCurrentMovies();
   MovieDTO getMovieDetails(Long Id);
   MovieDTO updateMovieDetails(Long movieId, MovieDTO dto);
   void removeCurrentMovie(Long movieId);
}
