package com.app.service;

import com.app.dto.TicketRequestDTO;

public interface BookingServiceIf {

	void getBookingsDone(TicketRequestDTO ticketRequest);
}
