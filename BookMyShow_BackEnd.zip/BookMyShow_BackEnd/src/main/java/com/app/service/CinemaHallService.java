package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.CinemaHallDaoIf;
import com.app.dto.CinemaHallDTO;
import com.app.pojo.CinemaHall;

@Service
@Transactional
public class CinemaHallService implements CinemaHallServiceIf {

	@Autowired
	private CinemaHallDaoIf cinemaHallDao;
	
	@Autowired
	private ModelMapper mapper;
	
	
	@Override
	public List<CinemaHallDTO> showCityHalls(String city) {
    	
		List<CinemaHall> cinemaHalls = cinemaHallDao.findByCity(city);
        return 
        	cinemaHalls.stream()
            .map(cinemaHall->mapper.map(cinemaHall, CinemaHallDTO.class))
            .collect(Collectors.toList());
            
	}

}
