package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exception.CustomException;
import com.app.dao.MovieDaoIf;
import com.app.dto.MovieDTO;
import com.app.pojo.Movie;
import com.app.pojo.MovieStatus;

@Service
@Transactional
public class MovieService implements MovieServiceIf {

	@Autowired
	private MovieDaoIf movieDao;
	
	@Autowired
	private ModelMapper mapper;
	
	@Override
	public MovieDTO addNewMovie(MovieDTO movie) {
		Movie m=mapper.map(movie, Movie.class);
		return mapper.map(movieDao.save(m), MovieDTO.class);
	}

	
	//---------------- for admin ---------------------------------------//
	@Override
	public List<Movie> getAllMovies() {
		return movieDao.findAllByOrderByMovieStatusAsc();
	}

	//-------------------for displaying current movies to user------------------//
	@Override
	public List<MovieDTO> getCityCurrentMovies(String city) {
		List<Movie>currentMovieList= movieDao.findByCityandMovieStatusCURRENT(city);
		return currentMovieList.stream()
				.map(movie->mapper.map(movie,MovieDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<MovieDTO> getCurrentMovies() {	
		List<Movie>currentMovieList= movieDao.findByMovieStatusCURRENT();
		return currentMovieList.stream()
				.map(movie->mapper.map(movie,MovieDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public MovieDTO getMovieDetails(Long Id) {
			Movie movie = movieDao.findById(Id).orElseThrow(()->new CustomException("Wrong id selected...!"));
			return mapper.map(movie, MovieDTO.class);
	}


	@Override
	public MovieDTO updateMovieDetails(Long movieId, MovieDTO dto) {
		Movie movie= movieDao.findById(movieId).orElseThrow(()->new CustomException("MovieId not valid....!"));
		mapper.map(dto, movie);
		movie.setId(movieId);
		return mapper.map(movie, MovieDTO.class);
	}


	@Override
	public void removeCurrentMovie(Long movieId) {
		Movie movie = movieDao.findById(movieId).orElseThrow(()->new CustomException("MovieId not valid....!"));
		movie.setMovieStatus(MovieStatus.OLD);
		movieDao.save(movie);
		
	}
	
	
	
	
	
	
//	public EmployeeRespDTO updateEmployee(Long empId, AddEmployeeDTO dto) {
//		// validate if emp exists by id
//		Employee emp = empRepo.findById(empId)
//				.orElseThrow(() -> new ResourceNotFoundException("Invalid Emo ID , Emp not found !!!!"));
//		// => emp exists
//		// validate confirm password
//		if (dto.getPassword().equals(dto.getConfirmPassword())) {
//			Department dept = deptRepo.findById(dto.getDeptId())
//					.orElseThrow(() -> new ResourceNotFoundException("Invalid Dept Id!!!"));
//			// dto contains the updates , so apply it --> to entity
//			mapper.map(dto, emp);// but after this id : null
//			emp.setId(empId);// so setting it again
//			// System.out.println("after mapping " + emp);
//			dept.addEmployee(emp);
//			return mapper.map(emp, EmployeeRespDTO.class);
//		}
//		throw new ApiException("Passwords don't match");
//
//	}
//	

}
