package com.app.service;

import java.time.LocalDateTime;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.dao.BookingDetailsDaoIf;
import com.app.dao.CinemaHallDaoIf;
import com.app.dao.MovieDaoIf;
import com.app.dao.SeatDaoIf;
import com.app.dao.ShowDaoIf;
import com.app.dto.TicketRequestDTO;
import com.app.dto.TicketResponseDTO;
import com.app.pojo.CinemaHall;
import com.app.pojo.CinemaHallSeat;
import com.app.pojo.Movie;

@Service
@Transactional
public class BookingService implements BookingServiceIf {

	@Autowired
    private BookingDetailsDaoIf bookingDao;
	
	@Autowired
	private SeatDaoIf seatDao;
	
	@Autowired
	private MovieDaoIf movieDao;
	
	@Autowired
	private CinemaHallDaoIf cinemaHallDao;
	
	@Autowired
	private ShowDaoIf showDao;
	
	@Override
	public void getBookingsDone(TicketRequestDTO ticketRequest) {
		Long seatId=ticketRequest.getSeatId();
	    CinemaHallSeat seat =  seatDao.findById(seatId).get();
	    seat.setAvailable(false);
	    seatDao.save(seat);
	    double total=seat.getPrice()*ticketRequest.getSeats();
	    Long movieId=ticketRequest.getMovieId();
	    Long showId=ticketRequest.getShowId();
	    String movieName = movieDao.findById(movieId).get().getMovieName();
	    LocalDateTime startTime = showDao.findById(showId).get().getStartTime();
	    LocalDateTime endTime= showDao.findById(showId).get().getEndTime();
	    
	    new TicketResponseDTO(total,LocalDateTime.now(),movieName,startTime,endTime);
	    
	}
	
	
}
