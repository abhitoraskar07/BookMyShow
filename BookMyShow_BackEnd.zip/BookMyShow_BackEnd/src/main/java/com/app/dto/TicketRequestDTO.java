package com.app.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class TicketRequestDTO {

	private Long showId;
	private Long seatId;
	private Long movieId;
	private Long userId;
    private int seats;
}
