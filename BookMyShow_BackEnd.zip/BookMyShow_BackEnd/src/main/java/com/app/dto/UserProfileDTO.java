package com.app.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.springframework.lang.Nullable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserProfileDTO {

	private Long id;
	@NotBlank(message = "first name can't be blank")
	private String firstName;
	@NotBlank(message = "last name can't be blank")
	private String lastName;
	@Email
	@NotBlank(message = "Email can't be blank")
	private String email;
	@NotBlank(message = "Password can't be blank")
	@Pattern(regexp = "((?=.*\\d)(?=.*[a-z])(?=.*[#@$*]).{5,20})",message = "invalid password format!!!!")
    private String password;
    @Column(unique = true)
    @Pattern(regexp = "^[1-9][0-9]{9}$", message = "Please enter a valid 10-digit mobile phone number")
    @Nullable
    private long mobile;
    @Past
    @Nullable
	private LocalDate dob;

}

