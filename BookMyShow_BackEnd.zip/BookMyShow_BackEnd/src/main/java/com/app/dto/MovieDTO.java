package com.app.dto;

import java.time.LocalDate;

import com.app.pojo.MovieStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MovieDTO {

	private Long id;
	private String movieName;
	
	private double rating;
	   
    private String gener;
	   
    private String languages;
    
    private String imagePath;
	   
	private LocalDate releaseDate;
	   
	private double duration;
	
	private MovieStatus movieStatus;
	  
}	
