package com.app.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class TicketResponseDTO {	
	private double totalAmt;
	private LocalDateTime timeStamp;
	private String movieName;
	private LocalDateTime startTime;
	private LocalDateTime endTime;
}
