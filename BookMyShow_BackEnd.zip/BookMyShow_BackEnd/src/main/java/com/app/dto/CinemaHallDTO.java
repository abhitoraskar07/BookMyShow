package com.app.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CinemaHallDTO {
	private Long id;
   private String cinemaHallName;
   private double cinemaHallRating;
   private int noOfScreens;
}
