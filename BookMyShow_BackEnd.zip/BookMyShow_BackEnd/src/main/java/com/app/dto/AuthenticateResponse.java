package com.app.dto;

import com.app.pojo.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AuthenticateResponse {
 private Long id;
 private String firstName;
 private String lastName;
 private String status;
 private String token;
 
 public AuthenticateResponse(Long id,User u,String token, String msg) {
	 this.firstName=u.getFirstName();
	 this.lastName=u.getLastName();
	 this.status=msg;
	 this.token=token;
 }
@Override
public String toString() {
	return "AuthenticateResponse [firstName=" + firstName + ", lastName=" + lastName + "]";
}
 
}
