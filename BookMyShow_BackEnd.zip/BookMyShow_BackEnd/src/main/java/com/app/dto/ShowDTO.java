package com.app.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import com.app.pojo.ShowStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class ShowDTO {

	private Long id;
     private LocalDateTime startTime;
     private LocalDateTime endTime;
     private Long movieId;
     private Long cinemaHallId;
     private Long screenId;
     @JsonIgnore
     private long showDuration;
     private ShowStatus showStatus;
     private boolean isFull;
     private LocalDate date;
     private double price;
     
     public void setDuration(long showDuration) {
      	 
      	 showDuration = this.startTime.until(this.endTime, ChronoUnit.HOURS);
      	 this.showDuration=showDuration;
     
       }
     
}
//id, end_time, start_time, cinemahall_id, movie_id,show_status,date,is_full,price,screen_id 