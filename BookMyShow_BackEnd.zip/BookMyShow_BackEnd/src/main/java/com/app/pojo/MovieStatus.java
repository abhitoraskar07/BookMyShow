package com.app.pojo;

public enum MovieStatus {
  CURRENT,DUPCOMING,OLD;
}
