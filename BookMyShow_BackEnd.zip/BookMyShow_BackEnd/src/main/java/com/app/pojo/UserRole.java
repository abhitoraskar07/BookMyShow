package com.app.pojo;

public enum UserRole {
  ROLE_ADMIN,ROLE_USER
}
