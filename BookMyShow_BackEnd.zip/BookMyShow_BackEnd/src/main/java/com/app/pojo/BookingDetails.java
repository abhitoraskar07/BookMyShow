package com.app.pojo;

import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "booking_details")
public class BookingDetails extends BaseEntity {
	
	private LocalDateTime timeStamp;
	
	@ManyToOne
	@JoinColumn(name = "show_id")
	private ShowDetails showDetails;
	
	@OneToOne(mappedBy = "booking")
	private PaymentDetails payment;
}
