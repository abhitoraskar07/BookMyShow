package com.app.pojo;

public class CinemaHallAddress {
	private String lane;
	private String street;
	private String city;
	private String state;
	private String country;
	private int pincode;
}
