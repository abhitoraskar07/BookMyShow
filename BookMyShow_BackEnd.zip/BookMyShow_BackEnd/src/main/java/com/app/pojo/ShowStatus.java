package com.app.pojo;

public enum ShowStatus {
	AUPCOMING,FEATURING,ZCLOSED
}
