package com.app.pojo;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "payment_details")
public class PaymentDetails extends BaseEntity{

	private String paymetMode;
	private boolean isSuccessfull;
	private LocalDateTime timeStamp;
	@OneToOne
	@JoinColumn(name = "booking_id")
	private BookingDetails booking;
}
