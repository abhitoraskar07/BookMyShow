package com.app.pojo;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "show_details")
public class ShowDetails extends BaseEntity {
   private LocalDateTime startTime;
   
   private LocalDateTime endTime;
   
   private LocalDate date;
   
   private boolean isFull;
   
   private double price;
   
   private long showDuration;
   
   @ManyToOne
   @JoinColumn(name = "cinemahall_id")
   private CinemaHall cinemaHall;
   
   @ManyToOne
   @JoinColumn(name = "screen_id")
   private CinemaHallScreen screen;
   
   @JsonIgnore
   @ManyToOne(fetch = FetchType.LAZY)
   @JoinColumn(name = "movie_id")
   private Movie movieSelected;   
     
   @OneToMany(mappedBy = "showDetails")
   private List<BookingDetails> bookingList;
   
   @Enumerated(EnumType.STRING)
   private ShowStatus showStatus;
   
   
   
}
