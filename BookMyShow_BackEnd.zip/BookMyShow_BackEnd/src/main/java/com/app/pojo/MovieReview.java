package com.app.pojo;

public class MovieReview {

}
