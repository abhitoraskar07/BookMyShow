package com.app.pojo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "cinema_hall")
public class CinemaHall extends BaseEntity{
   
	private String cinemaHallName;
   
	private String city;
	
	private double cinemaHallRating;
	
	private int noOfScreens;
	
	@OneToMany(mappedBy = "cinemaHall")
	private List<CinemaHallScreen> screens;
	
}
