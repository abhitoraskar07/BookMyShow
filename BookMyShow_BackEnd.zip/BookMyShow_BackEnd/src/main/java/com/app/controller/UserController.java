package com.app.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.app.dto.TicketRequestDTO;
import com.app.dto.UserProfileDTO;
import com.app.service.BookingServiceIf;
import com.app.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController{
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private BookingServiceIf bookingService;
	
	@PutMapping("/editProfile/{userId}")
	public ResponseEntity<String> updateMovieDetails(@PathVariable Long userId, @RequestBody UserProfileDTO user) {
		
		userService.updateUserDetails(userId, user);
		return ResponseEntity.ok("Profile Updated Successfully...");
	}
	
	@PostMapping("/{userId}/{movieId}/{showId}/get_my_booking/{seatId}/done")
	public void bookMovieTicket(@PathVariable Long userId,Long movieId,Long showId,Long seatId, @RequestBody int seats) {
		TicketRequestDTO ticket = new TicketRequestDTO(showId,seatId,userId,movieId,seats);
		bookingService.getBookingsDone(ticket);
	}
	
}
