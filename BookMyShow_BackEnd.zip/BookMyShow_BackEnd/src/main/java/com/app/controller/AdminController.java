package com.app.controller;

import static org.springframework.http.MediaType.IMAGE_GIF_VALUE;
import static org.springframework.http.MediaType.IMAGE_JPEG_VALUE;
import static org.springframework.http.MediaType.IMAGE_PNG_VALUE;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.dto.ApiResponse;
import com.app.dto.MovieDTO;
import com.app.dto.ShowDTO;
import com.app.pojo.Movie;
import com.app.service.ImageFileServiceIf;
import com.app.service.MovieServiceIf;
import com.app.service.ShowServiceIf;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController{
   
	
	@Autowired
	private ImageFileServiceIf imgService;

	@Value("${project.image}")
	private String folderLocation;
	
	@Autowired
	MovieServiceIf movieService;
	
	@Autowired
	ShowServiceIf showService;
	
	@GetMapping
	public List<Movie> getMovies(){
		return movieService.getAllMovies();
	}
	
	@PostMapping("/addMovie")
	public ResponseEntity<?> addMovie(@RequestPart("data") MovieDTO movie, @RequestPart("image") MultipartFile image) {
		 
		 String fileName =null;
	        try {
	            fileName = this.imgService.uploadImage(folderLocation,image);
	        } catch (Exception e) {
	            // TODO: handle exception
	            e.printStackTrace();
		        return new ResponseEntity<>(new ApiResponse("Image uploading failed.......!!"),HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	        
	        movie.setImagePath(fileName);	     
	        movieService.addNewMovie(movie); 
	  return new ResponseEntity<>("Movie added Successfully!!!", HttpStatus.OK);
	}
	
	//--------------------------- Adding show details of a movie ---------------------//
	@PostMapping("/{movieId}")
	public ResponseEntity<String> addMovieShowDetails(@PathVariable Long movieId, @RequestBody ShowDTO sh_dtls) {		
         showService.addShowDetailsOfExistingMovie(movieId, sh_dtls);
   	  return new ResponseEntity<>("Movie added Successfully!!!", HttpStatus.OK);
	}
     
	//---------------------------- Remove show with the given Id ----------------------//
	@GetMapping("/{movieId}/{showId}")
	public void removeShow(@PathVariable Long showId) {
		showService.removeShowDetails(showId);
	}
	
	//------------------------Editing Movie Details--------------------------------//
	@PutMapping("/editMovie/{movieId}")
	public ResponseEntity<String> updateMovieDetails(@PathVariable Long movieId, @RequestBody MovieDTO movie) {
		movieService.updateMovieDetails(movieId, movie);
		return ResponseEntity.ok("Movie Updated Successfully...");
	}
	
	//------------------------- Remove Current Movie--------------------------------------//
	@PutMapping("/removeMovie/{movieId}")
	public ResponseEntity<String> removeCurrentMovie(@PathVariable Long movieId){
		movieService.removeCurrentMovie(movieId);
		return ResponseEntity.ok("Current Movie Removed Successfully......!!");
	}
	
	
	//------------------------Editing Show details--------------------------------------//
	@PutMapping("/{movieId}/{showId}")
	public ResponseEntity<String> updateShowDetails(@PathVariable Long showId, @RequestBody ShowDTO movie) {
		
		return ResponseEntity.ok("Show Details Updated Successfully...");
	}

	
	
	
	
//	 @PostMapping("/upload")
//	    public ResponseEntity<ApiResponse> fileUpload(@RequestParam("image") MultipartFile image){
//	        
//	        String fileName =null;
//	        try {
//	            fileName = this.imgService.uploadImage(folderLocation,image);
//	        } catch (Exception e) {
//	            // TODO: handle exception
//	            e.printStackTrace();
//		        return new ResponseEntity<>(new ApiResponse("Image uploading failed.......!!"),HttpStatus.INTERNAL_SERVER_ERROR);
//	        }
//	        
//
//	        return new ResponseEntity<>(new ApiResponse("Image successfully uploaded!!"),HttpStatus.OK);
//	        
//	    }

	//-------------------- serve(download image) of specific MOVIE------------------------------//
	
	// http://host:port/admin/images/{movieId} , method=GET
//	@GetMapping(value="/movie/image/{movieId}",produces = {IMAGE_GIF_VALUE,
//				IMAGE_JPEG_VALUE,IMAGE_PNG_VALUE})
//	public ResponseEntity<?> serveEmpImage(@PathVariable Long movieId) throws IOException {
//	System.out.println("in download img " + movieId);
//	return ResponseEntity.ok(imgService.downloadImage(movieId));
//	
//	}

	
}
