package com.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AuthenticateResponse;
import com.app.dto.CinemaHallDTO;
import com.app.dto.MovieDTO;
import com.app.dto.ShowDTO;
import com.app.dto.SignInRequest;
import com.app.dto.SignUpRequest;
import com.app.pojo.CinemaHall;
import com.app.pojo.Movie;
import com.app.service.CinemaHallServiceIf;
import com.app.service.MovieServiceIf;
import com.app.service.ShowServiceIf;
import com.app.service.UserService;

@RestController
@RequestMapping("/home")
public class HomeController {

	@Autowired
	private CinemaHallServiceIf cinemaHallService;
	
	@Autowired
	private MovieServiceIf movieService;
	
	@Autowired
	private ShowServiceIf showService;
	
	@Autowired
	private UserService userService;
	
	@GetMapping
	public List<MovieDTO> getCurrentMovies(){
		return movieService.getCurrentMovies();
	}
	
	@GetMapping("/{city}/cinemahalls")
	public List<CinemaHallDTO> showCityHalls(@PathVariable String city){
		return cinemaHallService.showCityHalls(city);
	}
	
	
	@GetMapping("/{city}")
	public List<MovieDTO> showCityCurrentMovies(@PathVariable String city){
		return movieService.getCityCurrentMovies(city);
	}
	
	@GetMapping("/{movieId}")
	public MovieDTO showMovieDetails(@PathVariable Long movieId){
		return movieService.getMovieDetails(movieId);
	}
	///not yet tested
	@GetMapping("/{city}/{movieId}/show_list")
	public List<ShowDTO> displayMovieShows(@PathVariable Long movieId){
		return showService.displayMovieShows(movieId);
	}
	
	@PostMapping("/register")
	public AuthenticateResponse addUser(@RequestBody @Valid SignUpRequest signUpUser) {
	   return userService.registerUser(signUpUser);	
	}
	
	@PostMapping("/login")
	public String signIn(@RequestBody @Valid SignInRequest signInUser) {
		return userService.signInUser(signInUser);
	}
	
}
